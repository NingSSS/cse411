
#include <iostream>
#include <boost/shared_ptr.hpp>
#include <boost/asio.hpp>
#include <boost/asio/placeholders.hpp>
#include <boost/system/error_code.hpp>
#include <boost/bind/bind.hpp>
#include <cstdint>
#include <iostream>
#include <sstream>
#include <openssl/sha.h>
#include <cstdint>
#include <vector>
#include <string>
#include <fstream>
#include <boost/date_time/posix_time/posix_time.hpp>
#include <boost/bind.hpp>
#include <boost/thread.hpp>
//#include "date.h"
#include <time.h>
using namespace boost::asio;
using namespace std;



std::string GetNowTime() {
    time_t setTime;
    time(&setTime);
    tm* ptm = localtime(&setTime);
    std::string time = std::to_string(ptm->tm_year + 1900)
    + "/"
    + std::to_string(ptm->tm_mon + 1)
    + "/"
    + std::to_string(ptm->tm_mday)
    + " "
    + std::to_string(ptm->tm_hour) + ":"
    + std::to_string(ptm->tm_min) + ":"
    + std::to_string(ptm->tm_sec);
    return time;
}

//test
    //std::cout << "now time: " << strTime << std::endl;


string sha256(const string str)
{
    char buf[2];
    unsigned char hash[SHA256_DIGEST_LENGTH];
    SHA256_CTX sha256;
    SHA256_Init(&sha256);
    SHA256_Update(&sha256, str.c_str(), str.size());
    SHA256_Final(hash, &sha256);
    std::string NewString = "";
    for(int i = 0; i < SHA256_DIGEST_LENGTH; i++)
    {
        sprintf(buf,"%02x",hash[i]);
        NewString = NewString + buf;
    }
    return NewString;
}

class Block {
public:
    string sHash;
    string sPrevHash;
    
    Block(uint32_t nIndexIn, const string &sDataIn);
    int getIndex();
    string MineBlock(uint32_t nDifficulty);
    
private:
    uint32_t _nIndex;
    uint32_t _nNonce;
    string _sData;
    time_t _tTime;
    
    string _CalculateHash() const;
};

Block::Block(uint32_t nIndexIn, const string &sDataIn) : _nIndex(nIndexIn), _sData(sDataIn)
{
    _nNonce = 0;
    _tTime = time(nullptr);
    
    sHash = _CalculateHash();
}

int Block::getIndex(){
    return _nIndex;
}

string Block::MineBlock(uint32_t nDifficulty)
{
    char cstr[nDifficulty + 1];
    for (uint32_t i = 0; i < nDifficulty; ++i)
    {
        cstr[i] = '0';
    }
    cstr[nDifficulty] = '\0';
    
    string str(cstr);
    
    while (sHash.substr(0, nDifficulty) != str)
    {
        _nNonce++;
        sHash = _CalculateHash();
    }
    
    cout << "Block mined: " << sHash << endl;
    return sHash;
}

inline string Block::_CalculateHash() const
{
    stringstream ss;
    ss << _nIndex << sPrevHash << _tTime << _sData << _nNonce;
    
    return sha256(ss.str());
}

class Blockchain {
public:
    Blockchain();
    Block _GetLastBlock() const;
    string AddBlock(Block bNew);
    
private:
    uint32_t _nDifficulty;
    vector<Block> _vChain;
    
    //Block _GetLastBlock() const;
};

Blockchain::Blockchain()
{
    _vChain.__emplace_back(Block(0, "Genesis Block"));
    _nDifficulty = 3;
}

string Blockchain::AddBlock(Block bNew)
{
    bNew.sPrevHash = _GetLastBlock().sHash;
    string a;
    a=bNew.MineBlock(_nDifficulty);
    _vChain.push_back(bNew);
    //cout<<"send msg complete"<<endl;
    return a;
}

Block Blockchain::_GetLastBlock() const
{
    return _vChain.back();
}
static Blockchain bChain;
//string a()
//{
//    string strTest = sHash;
//    return strTest;
//}

/*** Receive text over the provided socket file descriptor, and send it back to* the client. When the client sends an EOF, return.** @paramsocket The socket file descriptor to use for the echo operation*/
//void echo_server(boost::asio::ip::tcp::socket &socket) {using namespace boost::asio;
//    // read data for as long as there is data, and always send it back
//    boost::system::error_code ignored_error;
//    ofstream outFile;
//    outFile.open("myfile.txt",ios::out);
//    Blockchain bChain = Blockchain();
//    string b;
//    while(true) {
//        char buf[128];
//        size_t len=socket.read_some(buffer(buf), ignored_error);
//        if(len>0) {
//            int intBuf = atoi(buf);
//            //cout << "Mining block 1..." << endl;
//            b=bChain.AddBlock(Block(intBuf, "Block 1 Data"));
//            outFile<<"The"<<intBuf<<"Block"<<":"<<b<<"\n"<<endl;
//            buf[len] =0;
//            write(socket, buffer(b), ignored_error);
//        }
//        if(len==0) {
//            break;
//        }
//    }
//    outFile.close();
//}
ofstream outFile("myfile.txt");
//outFile.open("myfile.txt",ios::out);
void Print(const boost::system::error_code &ec,
           boost::asio::deadline_timer* pt,
           int * pcount)
{
    if (*pcount < 3)
    {
        //Blockchain bChain = Blockchain();
        string result;
        Block lastBlock = bChain._GetLastBlock();
        string lastBlockHash = lastBlock.sHash;
        int lastBlockIndex = lastBlock.getIndex();
        int nIndexIn=lastBlockIndex+1;
        std::string strTime = GetNowTime();
        Block newBlock = Block(nIndexIn,strTime);
        newBlock.sPrevHash = lastBlockHash;
        //newBlock.MineBlock(3);
        result = bChain.AddBlock(newBlock);
        //result = bChain.AddBlock(Block(1, "Block Data"));
        outFile << "Mining Block:"<<strTime<<" mined:"<<result<<endl ;
        pt->expires_at(pt->expires_at() + boost::posix_time::seconds(60)) ;
        
        pt->async_wait(boost::bind(Print, boost::asio::placeholders::error, pt, pcount));
        
    }
}

void thread(){
    boost::asio::io_service io;
    boost::asio::deadline_timer t(io, boost::posix_time::seconds(1));
    int count = 0;
    t.async_wait(boost::bind(Print, boost::asio::placeholders::error, &t, &count));
    
    io.run();
    cout<<"finish"<<endl;
}

void echo_server(boost::asio::ip::tcp::socket &socket) { using namespace boost::asio;
    // read data for as long as there is data, and always send it back
    boost::system::error_code ignored_error;
//    ofstream outFile;
//    outFile.open("myfile.txt",ios::out);
    char buf[128];
    //Blockchain bChain = Blockchain();
    string result;
    //boost::asio::io_service io_service;

    
    while (true) {
        
        size_t len = socket.read_some(buffer(buf), ignored_error);
        if (len > 0) {
            int intBuf = atoi(buf);
            Block lastBlock = bChain._GetLastBlock();
            string lastBlockHash = lastBlock.sHash;
            int lastBlockIndex = lastBlock.getIndex();
            int nIndexIn=lastBlockIndex+1;
            Block newBlock = Block(nIndexIn,buf);
            newBlock.sPrevHash = lastBlockHash;
            //newBlock.MineBlock(3);
            result = bChain.AddBlock(newBlock);
            buf[len] = 0;
            write(socket, buffer(result), ignored_error);
            outFile << "Mining Block:"<<buf<<" mined:"<<result<<endl ;
            //timer.wait();
        }
        if (len == 0) {
            break;
        }
    }
    outFile.close();
}

int main(int argc, char *argv[]) {
    using namespace std;
    bChain = Blockchain();
    size_t port=6688; // Get port as size_tfrom argv
    try{
        // boost::asioalways needs a service
        boost::asio::io_service io_service;// Set up the server socket for listening
        boost::asio::ip::tcp::acceptor server_socket(io_service,boost::asio::ip::tcp::endpoint(boost::asio::ip::tcp::v4(), port));
        //deadline_timer timer(io_service, boost::posix_time::seconds(60));
        
        boost::thread t(thread);
//        string a;
//        a=bChain.AddBlock(Block(intBuf, "Block Data"));
//        cout << "another thread" << endl;
        
//        int i=1;
//        Blockchain bChain = Blockchain();
//        while(i>-0){
//            cout<<i<<" "<<endl;
//            string sss;
//            sss=bChain.AddBlock(Block(i, "Block Data"));
//            timer.wait();
//            i++;
//        }
        // Use accept() to wait for a client to connect. When it connects, service
        // it. When it disconnects, then and only then will we accept a new client.
        while(true) {
            cout<<"Waiting for a client to connect..."<<endl;
            boost::asio::ip::tcp::socket client(io_service);
            server_socket.accept(client);
            cout<<"Connected to "<<client.remote_endpoint().address().to_string() <<endl;
            echo_server(client);
            client.close();
        }
        server_socket.close();
    } catch(std::exception &e) {
        std::cerr<<e.what() <<std::endl;
    }
    return 0;
}




