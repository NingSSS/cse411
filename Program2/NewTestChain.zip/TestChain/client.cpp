#include<boost/asio.hpp>
#include<iostream>
/*** Connect to a server so that we can have bidirectional communication on the* socket (represented by a file descriptor) that this function returns** @paramhostname The name of the server (ipor DNS) to connect to* @paramport The server's port that we should use
 */
boost::asio::ip::tcp::socket connect_to_server(std::string hostname,std::string port) {
    using namespace boost::asio;
    io_service io_service;
    ip::tcp::resolver resolver(io_service);
    ip::tcp::resolver::query query(hostname, port);
    ip::tcp::resolver::iterator endpoint_iterator=resolver.resolve(query);
    ip::tcp::socket socket(io_service);
    connect(socket, endpoint_iterator);
    return socket;
}

void echo_client(boost::asio::ip::tcp::socket &socket) {
    using namespace std;
    using namespace boost::asio;
    // track connection duration, bytes transmitted
    size_t xmitBytes=0;
    struct timeval start_time, end_time;
    gettimeofday(&start_time, nullptr);
    // read from stdinfor as long as it isn't EOF, send to server, printreply
    while(true) {
        // Get the data from stdin. This assumes that we haven't redirected stdin
        // to a socket
        cout<<"Client: ";
        string data;
        getline(cin, data);
        if(cin.eof()) {
            break;
        }
        boost::system::error_code ignored_error;
        write(socket, buffer(data), ignored_error);
        xmitBytes+=data.length();
        // get back from server... This needs to handle short counts
        cout<<"Server: ";
        size_t recd=0;
        while(recd<data.length()) {
            char buf[128];
            size_t len=socket.read_some(boost::asio::buffer(buf), ignored_error);
            if(len>0) {
                recd+=len;
                buf[len] =0;
                cout<<buf;
            }
        }
        cout<<endl;
    }
    gettimeofday(&end_time, nullptr);
    cout<<endl<<"Transmitted "<<xmitBytes<<" bytes in "<<(end_time.tv_sec-start_time.tv_sec) <<" seconds"<<endl;
}

int main(int argc, char *argv[]) {
    std::string server_name="localhost";
    std::string port="6688"; // Get server_nameand port as strings from argv
    try{// Set up the client socket
        auto socket =connect_to_server(server_name, port);
        std::cout<<"Connected"<<std::endl;
        // Start the 'echo' interaction
        echo_client(socket);
        // clean up when done
        socket.close();
    } catch(std::exception &e) {std::cerr<<e.what() <<std::endl;
    }
    return 0;
}
